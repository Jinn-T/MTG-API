package com.example.MTGapiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtgApiProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
