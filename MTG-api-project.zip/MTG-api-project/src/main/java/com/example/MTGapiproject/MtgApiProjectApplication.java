package com.example.MTGapiproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtgApiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtgApiProjectApplication.class, args);
	}

}
